// pages/settings/settings.js
const app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    statusBarHeight: app.globalData.statusBarHeight,
    refreshing: false,
    refreshed: true,
    settings: {
      corsInfo: {
        icon: '/images/cors.png',
        name: '参考站连接',
        status: false,
        textStyle: 'red'
      },
      facility: {
        icon: '/images/facility_connect.png',
        name: '设备连接',
        status: false,
        positionMode: 0,
        count: 0,
        textStyle: 'red'
      },
      communicationMode: {
        icon: '/images/common_mode.png',
        name: '差分通信模式'
      }
    }
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    this.setData({
      refreshing: false,
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },
  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {
    console.log("aaa");
  },
  refresh() {
    // 这是做网络请求的时机
    const that = this
    // wx.showToast({
    //   title: 'refresh回调触发，做一些网络请求...',
    //   icon: 'none',
    //   complete() {
    //     // 成功或者失败之后，将refreshed设为true，收起下拉刷新组件
    //     setTimeout(() => {
    //       that.setData({
    //         refreshed: true,
    //       })
    //     }, 2000)
    //   }
    // });
    setTimeout(() => {
      that.setData({
        refreshed: true,
      })
    }, 2000)
  },
})