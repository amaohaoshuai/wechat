var time = require("../../utils/util.js")
const app = getApp();
var count = 0;
Page({
  data: {
    statusBarHeight: app.globalData.statusBarHeight,
    projects: [],
    istrue: false,
    refreshing: false,
    refreshed: false,
  },
  onLoad: function() {
    
  },
  onShow: function() {
    let projects = [{
      projectId: '34232sda',
      projectName: '金台线测试',
      projectStatus: '坐标转换',
      saveTime: time.formatTime(new Date())
    },
    {
      projectId: '3423243sda',
      projectName: '跨海大桥测试',
      projectStatus: '首尾点放样',
      saveTime: time.formatTime(new Date())
    },
    {
      projectId: '342324sda',
      projectName: '温岭测试',
      projectStatus: '坐标推算',
      saveTime: time.formatTime(new Date())
    },
    {
      projectId: '342352sda',
      projectName: '石河子测试',
      projectStatus: '坐标推算',
      saveTime: time.formatTime(new Date())
    }
    ];
    this.setData({
      refreshing: false,
      istrue: false,
      projects: projects
    });
  },
  refresh() {
    // 这是做网络请求的时机
    const that = this
    let projects = [{
        projectId: '3423322sda',
        projectName: '金台线测试',
        projectStatus: '坐标转换',
        saveTime: time.formatTime(new Date())
      },
      {
        projectId: '3423432sda',
        projectName: '跨海大桥测试',
        projectStatus: '首尾点放样',
        saveTime: time.formatTime(new Date())
      },
      {
        projectId: '3423432sda',
        projectName: '温岭测试',
        projectStatus: '坐标推算',
        saveTime: time.formatTime(new Date())
      },
      {
        projectId: '34232s43da',
        projectName: '石河子测试',
        projectStatus: '坐标推算',
        saveTime: time.formatTime(new Date())
      },
      {
        projectId: '34232sda12',
        projectName: '金台线测试',
        projectStatus: '坐标转换',
        saveTime: time.formatTime(new Date())
      },
      {
        projectId: '34232sda123',
        projectName: '跨海大桥测试',
        projectStatus: '首尾点放样',
        saveTime: time.formatTime(new Date())
      },
      {
        projectId: '34232sdafd',
        projectName: '温岭测试',
        projectStatus: '坐标推算',
        saveTime: time.formatTime(new Date())
      },
      {
        projectId: '34232sdrqa',
        projectName: '石河子测试',
        projectStatus: '坐标推算',
        saveTime: time.formatTime(new Date())
      },
      {
        projectId: '34232s43da',
        projectName: '石河子测试',
        projectStatus: '坐标推算',
        saveTime: time.formatTime(new Date())
      },
      {
        projectId: '34232sda12',
        projectName: '金台线测试',
        projectStatus: '坐标转换',
        saveTime: time.formatTime(new Date())
      },
      {
        projectId: '34232s43da',
        projectName: '石河子测试',
        projectStatus: '坐标推算',
        saveTime: time.formatTime(new Date())
      },
      {
        projectId: '34232sda12',
        projectName: '金台线测试',
        projectStatus: '坐标转换',
        saveTime: time.formatTime(new Date())
      },
      {
        projectId: '34232s43da',
        projectName: '石河子测试',
        projectStatus: '坐标推算',
        saveTime: time.formatTime(new Date())
      },
      {
        projectId: '34232sda12',
        projectName: '金台线测试',
        projectStatus: '坐标转换',
        saveTime: time.formatTime(new Date())
      },
      {
        projectId: '34232s43da',
        projectName: '石河子测试',
        projectStatus: '坐标推算',
        saveTime: time.formatTime(new Date())
      },
      {
        projectId: '34232sda12',
        projectName: '金台线测试',
        projectStatus: '坐标转换',
        saveTime: time.formatTime(new Date())
      }
    ];
    that.setData({
      projects: projects
    });
    // 成功或者失败之后，将refreshed设为true，收起下拉刷新组件
    setTimeout(() => {
      that.setData({
        refreshed: true,
      })
    }, 2000)
  },
  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {
    var that = this;
    // 显示加载图标
    wx.showLoading({
      title: '玩命加载中',
    })
    if (count < 3) {
      setTimeout(function() {
        let projects = [{
            projectId: '34232sbfdda',
            projectName: '金台线测试1',
            projectStatus: '坐标转换',
            saveTime: time.formatTime(new Date())
          },
          {
            projectId: '34232fdssda',
            projectName: '跨海大桥测试1',
            projectStatus: '首尾点放样',
            saveTime: time.formatTime(new Date())
          },
          {
            projectId: '34232sdewa',
            projectName: '温岭测试1',
            projectStatus: '坐标推算',
            saveTime: time.formatTime(new Date())
          },
          {
            projectId: '34232sgfda',
            projectName: '石河子测试1',
            projectStatus: '坐标推算',
            saveTime: time.formatTime(new Date())
          },
          {
            projectId: '34232sdnga',
            projectName: '金台线测试1',
            projectStatus: '坐标转换',
            saveTime: time.formatTime(new Date())
          }
        ];
        let oldData = that.data.projects;
        that.setData({
          projects: oldData.concat(projects)
        });
        count++;
      }, 2000);
    }
    console.log("reach:" + this.data.projects);
    setTimeout(function () {
      wx.hideLoading();
    }, 2000);
  },
  openDialog: function() {
    this.setData({
      istrue: true
    })
  },
  closeDialog: function() {
    this.setData({
      istrue: false
    })
  },
});